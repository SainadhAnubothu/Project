package com.cg.employeemaintenancesystem.service;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.employeemaintenancesystem.dao.IEMSDao;
import com.cg.employeemaintenancesystem.entity.Employee;
import com.cg.employeemaintenancesystem.entity.LeaveHistory;
import com.cg.employeemaintenancesystem.entity.UserMaster;

@Service
public class EMSServiceImpl implements IEMSService{
	@Autowired
	IEMSDao employeeDao;
	
	
	@Override
	public ArrayList<UserMaster> checkLoginCredentials(String userName, String userPassword) {
		return employeeDao.checkLoginCredentials(userName, userPassword);
	}

	@Override
	public String adminAddEmployee(Employee employee) {
		System.out.println("Inservice");
		return employeeDao.adminAddEmployee(employee);
	}

	@Override
	public String adminModifyEmployee(String employeeId) {
		return employeeDao.adminModifyEmployee(employeeId);
	}

	@Override
	public ArrayList<Employee> adminDisplayAllEmployees() {
		return employeeDao.adminDisplayAllEmployees();
	}

	@Override
	public ArrayList<LeaveHistory> adminLeaveDecision(String userId,
			String decision) {
		return employeeDao.adminLeaveDecision(userId, decision);
	}

	@Override
	public ArrayList<Employee> userIdSearchEmployee(String employeeId) {
		return employeeDao.userIdSearchEmployee(employeeId);
	}

	@Override
	public ArrayList<Employee> userFirstNameSearchEmployee(String firstName) {
		return employeeDao.userFirstNameSearchEmployee(firstName);
	}

	@Override
	public ArrayList<Employee> userLastNameSearchEmployee(String lastName) {
		return employeeDao.userLastNameSearchEmployee(lastName);
	}

	@Override
	public ArrayList<Employee> userGradeSearchEmployee(String gradeCode) {
		return employeeDao.userGradeSearchEmployee(gradeCode);
	}

	@Override
	public ArrayList<Employee> userDepartmentSearchEmployee(
			String departmentName) {
		return employeeDao.userDepartmentSearchEmployee(departmentName);
	}

	@Override
	public ArrayList<Employee> userMaritalStatusSearchEmployee(
			String maritalStatus) {
		return employeeDao.userMaritalStatusSearchEmployee(maritalStatus);
	}

	@Override
	public ArrayList<LeaveHistory> userApplyLeave(LeaveHistory leaveHistory) {
		return employeeDao.userApplyLeave(leaveHistory);
	}

	@Override
	public ArrayList<LeaveHistory> adminApproveLeave(Integer leaveId) {
		return employeeDao.adminApproveLeave(leaveId);
	}

	@Override
	public ArrayList<LeaveHistory> adminRejectLeave(Integer leaveId) {
		return employeeDao.adminRejectLeave(leaveId);
	}

}
