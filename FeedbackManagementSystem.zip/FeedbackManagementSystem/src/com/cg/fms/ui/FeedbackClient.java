package com.cg.fms.ui;

import java.util.ArrayList;
import java.util.Scanner;
import com.cg.fms.bean.FeedackManagementBean;
import com.cg.fms.service.FeedbackManagementService;
import com.cg.fms.service.IFeedbackManagementService;

public class FeedbackClient {
	public static void main(String[] args) {
		boolean result=false;
		boolean result1=false;
		IFeedbackManagementService service=new FeedbackManagementService();
		System.out.println("Welcome to Feedback Management System1");
		System.out.println("-------------------------------------------");
		System.out.println("Please enter your employee ID:");
		Scanner scannerID=new Scanner(System.in);
		int employeeID=scannerID.nextInt();
		ArrayList<FeedackManagementBean> arrayList=new ArrayList<FeedackManagementBean>();
		arrayList=service.retrieveDetails(employeeID);
		for (FeedackManagementBean feedackManagementBean : arrayList) {
			System.out.println("Welcome "+feedackManagementBean.getEmployeeName()+"\nRole is: "+feedackManagementBean.getRole());

			switch (feedackManagementBean.getRole()) {
			case "Admin":
				System.out.println("1.Faculty Skill Maintainence 2.Course Maintainence 3.View Feedback Report");
				Scanner scannerAdminChoice=new Scanner(System.in);
				int choice=scannerAdminChoice.nextInt();
				switch (choice) {
				case 1:
					IFeedbackManagementService service1=new FeedbackManagementService();
					ArrayList<FeedackManagementBean> skillList=new ArrayList<FeedackManagementBean>();
					skillList=service1.retrieveFacultyDetails();
					System.out.println("Faculty Details are:");
					for (FeedackManagementBean feedackManagementBean2 : skillList) {
						System.out.println("Faculty ID: "+feedackManagementBean2.getFacultyId()+"\nSkill Set: "+feedackManagementBean2.getSkillSet());
						System.out.println("-----------------------------------");
					}
					break;
				case 2:
					IFeedbackManagementService service2=new FeedbackManagementService();
					ArrayList<FeedackManagementBean> courseList=new ArrayList<FeedackManagementBean>();
					courseList=service2.retrieveCourseDetails();
					System.out.println("Course Details are:");
					for (FeedackManagementBean feedackManagementBean2 : courseList) {
						System.out.println("Course ID: "+feedackManagementBean2.getCourseId()+"\nCourse Name: "
								+feedackManagementBean2.getCourseName()+"\nNo of Days: "+feedackManagementBean2.getNoOfDays());
						System.out.println("-----------------------------------");
					}
					break;
				case 3:
					IFeedbackManagementService service3=new FeedbackManagementService();
					result1=service3.viewFeedbackDetails();
					
					break;
				default:
					break;
				}

			case "Cordinator":
				
				break;


			case "Participant":
				IFeedbackManagementService service3=new FeedbackManagementService();
				System.out.println("1.All Training programs report 2.Faculty wise report");
				System.out.println("-----------------------------------------------------");
				Scanner scanner=new Scanner(System.in);
				int option=scanner.nextInt();
				switch (option) {
				case 1:
					System.out.println("Rate between 1 to 5");
					System.out.println("Training code:\n Faculty ID: \nFeedback Scores");
					System.out.println("Presentation & communication");
					Scanner scanner2=new Scanner(System.in);
					int presComm=scanner2.nextInt();
					System.out.println("Clarify Doubts");
					Scanner scanner3=new Scanner(System.in);
					int clrDbts=scanner3.nextInt();
					System.out.println("Time Management");
					Scanner scanner4=new Scanner(System.in);
					int tm=scanner4.nextInt();
					System.out.println("Handout");
					Scanner scanner5=new Scanner(System.in);
					int hndout=scanner5.nextInt();
					System.out.println("H/W S/W Networks usage");
					Scanner scanner6=new Scanner(System.in);
					int hsn=scanner6.nextInt();
					System.out.println("nComments");
					Scanner scanner7=new Scanner(System.in);
					String comments=scanner7.next();
					System.out.println("Suggestions");
					Scanner scanner8=new Scanner(System.in);
					String sugg=scanner8.next();
					result=service3.addFeedbackDetails(employeeID,presComm,clrDbts,tm,hndout,hsn,comments,sugg);
					if(result==true){
						System.out.println("Thank you!!!");
					}
					break;
					
				case 2:
					
				break;

				default:
					break;
				}

			default:
				break;
			}

		}

	}
}
