package com.cg.fms.util;

import java.sql.Connection;
import java.sql.DriverManager;

public class DBUtil {
	static Connection connection=null;
	public static Connection conn(){
		try{
			Class.forName("oracle.jdbc.driver.OracleDriver");  
			connection=DriverManager.getConnection( "jdbc:oracle:thin:@10.219.34.3:1521:orcl","trg328","training328");  
		}
		catch(Exception exception){
			exception.printStackTrace();
		}
		return connection;
	}
}
