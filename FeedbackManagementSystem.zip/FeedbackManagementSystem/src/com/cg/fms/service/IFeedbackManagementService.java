package com.cg.fms.service;

import java.util.ArrayList;

import com.cg.fms.bean.FeedackManagementBean;

public interface IFeedbackManagementService {
	public ArrayList<FeedackManagementBean> retrieveDetails(int employeeID);
	public ArrayList<FeedackManagementBean> retrieveFacultyDetails();
	public ArrayList<FeedackManagementBean> retrieveCourseDetails();
	public boolean addFeedbackDetails(int employeeID,int presComm,int clrDbts,int tm,int hndout,int hsn,String comments,String sugg);
	public boolean viewFeedbackDetails();
}
