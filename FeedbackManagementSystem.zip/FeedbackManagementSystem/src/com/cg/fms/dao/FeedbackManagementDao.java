package com.cg.fms.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import com.cg.fms.bean.FeedackManagementBean;
import com.cg.fms.util.DBUtil;

public class FeedbackManagementDao implements IFeedbackManagementDao{

	boolean value=false;
	boolean value1=false;
	static Connection connection=null;
	PreparedStatement preparedStatement=null;
	PreparedStatement preparedStatement1=null;
	ResultSet resultSet=null;
	ResultSet resultSet1=null;
	
	@Override
	public ArrayList<FeedackManagementBean> retrieveDetails(int employeeID) {
		ArrayList<FeedackManagementBean> list=new ArrayList<FeedackManagementBean>();
		try{
			connection=DBUtil.conn();
			preparedStatement=connection.prepareStatement("SELECT employee_name,role FROM employee_master WHERE employee_id=?");
			preparedStatement.setInt(1, employeeID);
			resultSet=preparedStatement.executeQuery();
			while(resultSet.next()){
				FeedackManagementBean bean=new FeedackManagementBean();
				String empName=resultSet.getString(1);
				String role=resultSet.getString(2);
				bean.setEmployeeName(empName);
				bean.setRole(role);
				list.add(bean);
			}
		}
		catch(Exception exception){
			exception.printStackTrace();
		}
		return list;
	}
	@Override
	public ArrayList<FeedackManagementBean> retrieveFacultyDetails() {
		ArrayList<FeedackManagementBean> skillList=new ArrayList<FeedackManagementBean>();
		try{
			connection=DBUtil.conn();
			preparedStatement=connection.prepareStatement("SELECT faculty_id,skill_set FROM faculty_skill");
			resultSet=preparedStatement.executeQuery();
			while(resultSet.next()){
				FeedackManagementBean bean1=new FeedackManagementBean();
				int facultyId=resultSet.getInt(1);
				String skillSet=resultSet.getString(2);
				bean1.setFacultyId(facultyId);
				bean1.setSkillSet(skillSet);
				skillList.add(bean1);
			}
		}
		catch(Exception exception){
			exception.printStackTrace();
		}
		return skillList;
	}
	@Override
	public ArrayList<FeedackManagementBean> retrieveCourseDetails() {
		ArrayList<FeedackManagementBean> courseList=new ArrayList<FeedackManagementBean>();
		try{
			connection=DBUtil.conn();
			preparedStatement=connection.prepareStatement("SELECT course_id,course_name,no_of_days FROM course_master");
			resultSet=preparedStatement.executeQuery();
			while(resultSet.next()){
				FeedackManagementBean bean1=new FeedackManagementBean();
				int courseId=resultSet.getInt(1);
				String courseName=resultSet.getString(2);
				int noOfDays=resultSet.getInt(3);
				bean1.setCourseId(courseId);
				bean1.setCourseName(courseName);
				bean1.setNoOfDays(noOfDays);
				courseList.add(bean1);
			}
		}
		catch(Exception exception){
			exception.printStackTrace();
		}
		return courseList;
	}
	@Override
	public boolean addFeedbackDetails(int employeeID,int presComm, int clrDbts, int tm,int hndout, int hsn,String comments,String sugg) {
		try{
			connection=DBUtil.conn();
			
			preparedStatement1=connection.prepareStatement("SELECT training_code FROM training_partici_enroll WHERE participant_id=?");
			preparedStatement1.setInt(1, employeeID);
			resultSet1=preparedStatement1.executeQuery();
			while(resultSet1.next()){
				int trCode=resultSet1.getInt(1);
				
				preparedStatement=connection.prepareStatement("INSERT INTO feedback_master values(?,?,?,?,?,?,?,?,?)");
				preparedStatement.setInt(1, trCode);
				preparedStatement.setInt(2,employeeID);
				preparedStatement.setInt(3, presComm);
				preparedStatement.setInt(4, clrDbts);
				preparedStatement.setInt(5, tm);
				preparedStatement.setInt(6, hndout);
				preparedStatement.setInt(7, hsn);
				preparedStatement.setString(8, comments);
				preparedStatement.setString(9, sugg);
				int n=preparedStatement.executeUpdate();
				
				if(n==1){
					value=true;
				}
				else{
					value=false;
				}
			}
			
		}
		catch(Exception exception){
			exception.printStackTrace();
		}
		return value;
	}
	@Override
	public boolean viewFeedbackDetails() {
		try{
			connection=DBUtil.conn();
			preparedStatement=connection.prepareStatement("SELECT * FROM feedback_master");
			resultSet=preparedStatement.executeQuery();
			//System.out.println(resultSet);
				if(resultSet!=null){
					value=true;
				}
				else{
					value=false;
				}
			}
			
		catch(Exception exception){
			exception.printStackTrace();
		}
		return value;
	}

}
