package com.cg.employeemaintenancesystem.controller;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.cg.employeemaintenancesystem.entity.UserMaster;
import com.cg.employeemaintenancesystem.service.IEMSService;

@Controller
public class EMSLogInController {
	@Autowired
	IEMSService employeeService; 
	@RequestMapping("/index")
	public String welcome()
	{
		return "HomePage";
	}
	@RequestMapping("/loginDetails")
	public ModelAndView displaylogIn()
	{
		ModelAndView modelView=new ModelAndView();
		UserMaster userMaster=new UserMaster();
		modelView.setViewName("LoginPage");
		modelView.addObject("loginBean",userMaster);
		return modelView;
	}
	@RequestMapping(value="checkcredentials",method=RequestMethod.POST)
	public ModelAndView checkLoginDetails(@ModelAttribute("loginBean") UserMaster userMaster)
	{
		ArrayList<UserMaster> userDetails=employeeService.checkLoginCredentials(userMaster.getUserName(), userMaster.getUserPassword());
		ModelAndView modelView=new ModelAndView();
		String user=null;
		if(!userDetails.isEmpty())
		{
			for (UserMaster userType : userDetails) {
				user=userType.getUserType();
			if("admin".equalsIgnoreCase(user))
				modelView.setViewName("AdminMainOptionPage");
			else
				modelView.setViewName("UserMainOptionPage");
			}
		}
		else
		{
			modelView.addObject("loginBean",userMaster);
			modelView.setViewName("LoginPage");
		}
		return modelView;
	}
}
